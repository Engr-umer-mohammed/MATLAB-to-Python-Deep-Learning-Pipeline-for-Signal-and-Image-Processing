import torch
from torch.utils.data import DataLoader
from torch import nn, optim
from dataset import SRDataset
from srcnn import SRCNN
import os

# Paths
lr_dir = "../data/LR"
hr_dir = "../data/HR"
results_dir = "../results"
os.makedirs(results_dir, exist_ok=True)

# Dataset
dataset = SRDataset(lr_dir, hr_dir)
loader = DataLoader(dataset, batch_size=1, shuffle=True)

# Model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = SRCNN().to(device)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=1e-4)

# Training loop
epochs = 50
for epoch in range(epochs):
    total_loss = 0
    for lr_img, hr_img in loader:
        lr_img = lr_img.to(device)
        hr_img = hr_img.to(device)

        optimizer.zero_grad()
        output = model(lr_img)
        loss = criterion(output, hr_img)
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
    print(f"Epoch [{epoch+1}/{epochs}], Loss: {total_loss/len(loader):.6f}")

# Save model
torch.save(model.state_dict(), os.path.join(results_dir, "srcnn.pth"))
print("Training completed and model saved!")
