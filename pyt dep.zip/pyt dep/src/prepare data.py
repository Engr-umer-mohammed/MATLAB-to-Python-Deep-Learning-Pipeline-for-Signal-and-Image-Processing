import cv2
import os

hr_path = "../data/HR"
lr_path = "../data/LR"

os.makedirs(hr_path, exist_ok=True)
os.makedirs(lr_path, exist_ok=True)

# Load grayscale image
img = cv2.imread("../data/sample_gray.jfif", cv2.IMREAD_GRAYSCALE)

# Resize to HR
hr = cv2.resize(img, (256, 256))

# Create LR version
lr = cv2.resize(hr, (64, 64), interpolation=cv2.INTER_CUBIC)

cv2.imwrite(f"{hr_path}/img1.png", hr)
cv2.imwrite(f"{lr_path}/img1.png", lr)

print("HR and LR images prepared.")
