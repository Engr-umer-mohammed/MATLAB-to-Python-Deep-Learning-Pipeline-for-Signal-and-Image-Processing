import torch
import matplotlib.pyplot as plt
from dataset import SRDataset
from srcnn import SRCNN
from torch.utils.data import DataLoader
from skimage.metrics import peak_signal_noise_ratio as psnr, structural_similarity as ssim

# Dataset
lr_dir = "../data/LR"
hr_dir = "../data/HR"
dataset = SRDataset(lr_dir, hr_dir)
loader = DataLoader(dataset, batch_size=1, shuffle=False)

# Load model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = SRCNN().to(device)
model.load_state_dict(torch.load("../results/srcnn.pth", map_location=device))
model.eval()

# Evaluate
for i, (lr_img, hr_img) in enumerate(loader):
    lr_img = lr_img.to(device)
    hr_img = hr_img.to(device)

    # Forward pass
    with torch.no_grad():
        sr_img = model(lr_img)

    # Convert to NumPy
    lr_np = lr_img.squeeze().cpu().numpy()
    hr_np = hr_img.squeeze().cpu().numpy()
    sr_np = sr_img.squeeze().cpu().numpy()

    # Compute metrics
    psnr_val = psnr(hr_np, sr_np, data_range=1.0)
    ssim_val = ssim(hr_np, sr_np, data_range=1.0)

    print(f"Image {i+1}: PSNR = {psnr_val:.2f}, SSIM = {ssim_val:.4f}")

    # Plot
    plt.figure(figsize=(12, 4))
    plt.subplot(1, 3, 1)
    plt.title("LR Input")
    plt.imshow(lr_np, cmap='gray')
    plt.subplot(1, 3, 2)
    plt.title("SRCNN Output")
    plt.imshow(sr_np, cmap='gray')
    plt.subplot(1, 3, 3)
    plt.title("HR Target")
    plt.imshow(hr_np, cmap='gray')
    plt.show()
