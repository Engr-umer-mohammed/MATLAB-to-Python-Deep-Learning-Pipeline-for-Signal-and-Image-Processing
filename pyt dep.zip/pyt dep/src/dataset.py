import os
from PIL import Image
from torch.utils.data import Dataset
import torchvision.transforms as transforms

class SRDataset(Dataset):
    def __init__(self, lr_dir, hr_dir):
        self.lr_files = sorted(os.listdir(lr_dir))
        self.hr_files = sorted(os.listdir(hr_dir))
        self.lr_dir = lr_dir
        self.hr_dir = hr_dir
        self.transform = transforms.ToTensor()

    def __len__(self):
        return len(self.lr_files)

    def __getitem__(self, idx):
        hr = Image.open(os.path.join(self.hr_dir, self.hr_files[idx])).convert('L')
        lr = Image.open(os.path.join(self.lr_dir, self.lr_files[idx])).convert('L')

        # Upsample LR to HR size
        lr_up = lr.resize(hr.size, resample=Image.BICUBIC)

        hr = self.transform(hr)
        lr_up = self.transform(lr_up)

        return lr_up, hr
