import sys
import os

# Add src folder to Python path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))


import os
from src.load_image import load_image
from src.add_noise import add_gaussian_noise
from src.denoise import denoise_image
from src.enhance import enhance_contrast
from src.edge_detect import detect_edges
from src.metrics import compute_metrics
from src.save_results import save_image, save_metrics_csv

# Paths
data_path = 'data/sample_gray.jfif'
results_dir = 'results'
if not os.path.exists(results_dir):
    os.makedirs(results_dir)

# Step 1: Load image
img = load_image(data_path)

# Step 2: Add Gaussian noise
noisy_img = add_gaussian_noise(img)

# Step 3: Denoise
denoised_img = denoise_image(noisy_img)

# Step 4: Enhance contrast
enhanced_img = enhance_contrast(denoised_img)

# Step 5: Edge detection
edges = detect_edges(enhanced_img)

# Step 6: Compute metrics
mse, psnr, ssim = compute_metrics(img, denoised_img)
print(f"Denoising MSE  = {mse:.6f}")
print(f"Denoising PSNR = {psnr:.2f} dB")
print(f"Denoising SSIM = {ssim:.4f}")

# Step 7: Save results
save_image(noisy_img, os.path.join(results_dir, 'noisy.png'))
save_image(denoised_img, os.path.join(results_dir, 'denoised.png'))
save_image(enhanced_img, os.path.join(results_dir, 'enhanced.png'))
save_image(edges.astype(float), os.path.join(results_dir, 'edges.png'))
metrics = {'MSE': mse, 'PSNR': psnr, 'SSIM': ssim}
save_metrics_csv(metrics, os.path.join(results_dir, 'metrics.csv'))
# =======================
# Your existing processing code
# =======================
# noisy_img = add_noise(img)
# denoised_img = denoise_image(noisy_img)
# enhanced_img = enhance_image(denoised_img)
# edges = detect_edges(enhanced_img)

# =======================
# Step: Display all images in one figure (professional summary)
# =======================
import matplotlib.pyplot as plt

fig, axs = plt.subplots(2, 3, figsize=(15, 10))  # 2 rows, 3 columns

axs[0, 0].imshow(img, cmap='gray')
axs[0, 0].set_title('Original')
axs[0, 0].axis('off')

axs[0, 1].imshow(noisy_img, cmap='gray')
axs[0, 1].set_title('Noisy')
axs[0, 1].axis('off')

axs[0, 2].imshow(denoised_img, cmap='gray')
axs[0, 2].set_title('Denoised')
axs[0, 2].axis('off')

axs[1, 0].imshow(enhanced_img, cmap='gray')
axs[1, 0].set_title('Enhanced')
axs[1, 0].axis('off')

axs[1, 1].imshow(edges, cmap='gray')
axs[1, 1].set_title('Edges')
axs[1, 1].axis('off')

# Optionally leave last subplot empty or use for another result
axs[1, 2].axis('off')

plt.tight_layout()
plt.show()
plt.savefig('results/summary.png')  # Save as high-quality figure
