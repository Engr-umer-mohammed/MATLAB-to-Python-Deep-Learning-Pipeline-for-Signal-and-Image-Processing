from skimage.metrics import mean_squared_error, peak_signal_noise_ratio, structural_similarity

def compute_metrics(original, processed):
    mse = mean_squared_error(original, processed)
    psnr = peak_signal_noise_ratio(processed, original, data_range=original.max() - original.min())
    ssim = structural_similarity(original, processed, data_range=original.max() - original.min())
    return mse, psnr, ssim
