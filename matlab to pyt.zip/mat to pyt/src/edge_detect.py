from skimage import feature

def detect_edges(img):
    edges = feature.canny(img)
    return edges
