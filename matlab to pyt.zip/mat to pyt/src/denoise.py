from skimage.restoration import denoise_bilateral

def denoise_image(img, sigma_color=0.09, sigma_spatial=1):
    # For recent scikit-image versions, use channel_axis=None for grayscale
    denoised = denoise_bilateral(img, sigma_color=sigma_color, sigma_spatial=sigma_spatial, channel_axis=None)
    return denoised
