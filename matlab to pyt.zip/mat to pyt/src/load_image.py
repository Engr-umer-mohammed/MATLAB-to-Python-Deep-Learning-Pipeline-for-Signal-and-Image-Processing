import numpy as np
from skimage import io, color, img_as_float

def load_image(path):
    img = io.imread(path)
    if img.ndim == 3:
        img = color.rgb2gray(img)
    img = img_as_float(img)
    return img
