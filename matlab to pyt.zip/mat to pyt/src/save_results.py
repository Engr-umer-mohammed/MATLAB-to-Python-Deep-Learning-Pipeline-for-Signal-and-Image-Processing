from skimage import io, img_as_ubyte
import os
import csv

def save_image(img, path):
    """
    Save an image to the specified path.
    Converts float images (0-1) to uint8 for PNG/JPG compatibility.
    """
    if img.dtype.kind == 'f':  # float image
        img_to_save = img_as_ubyte(img)
    else:
        img_to_save = img

    os.makedirs(os.path.dirname(path), exist_ok=True)
    io.imsave(path, img_to_save)


def save_metrics_csv(metrics_dict, path):
    """
    Save a dictionary of metrics (e.g., MSE, PSNR, SSIM) to a CSV file.
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Metric', 'Value'])
        for key, value in metrics_dict.items():
            writer.writerow([key, value])
