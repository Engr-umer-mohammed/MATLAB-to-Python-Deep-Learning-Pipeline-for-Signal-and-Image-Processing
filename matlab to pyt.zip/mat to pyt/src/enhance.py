from skimage import exposure

def enhance_contrast(img):
    return exposure.adjust_gamma(img, gamma=0.8)
