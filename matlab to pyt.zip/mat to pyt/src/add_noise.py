import numpy as np

def add_gaussian_noise(img, mean=0, var=0.01):
    noisy = img + np.random.normal(mean, np.sqrt(var), img.shape)
    noisy = np.clip(noisy, 0, 1)
    return noisy


